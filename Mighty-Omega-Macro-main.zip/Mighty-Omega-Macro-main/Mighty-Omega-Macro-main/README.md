<div id="top"></div>

<h3 align="center">Mighty Omega Macro</h3>

  <p align="center">
    Macro for mighty omega using Autohotkey!
    <br />
    <a href="https://www.roblox.com/games/4878988249/BERSERK-MODE-NEW-CLANS-Mighty-Omega"><strong>Game Link »</strong></a>
    <br />
    <br />
    <a href="https://discord.gg/4rxfjtnMGt">Discord</a>
    ·
    <a href="https://discord.gg/4rxfjtnMGt">Report Bug</a>
    ·
    <a href="https://discord.gg/4rxfjtnMGt">Request Feature</a>
  </p>
</div>







<!-- ABOUT THE PROJECT -->
## About The Project
Free macro for Mighty Omega. My Discord for more info [Link](https://discord.gg/4rxfjtnMGt)





<!-- GETTING STARTED -->
## Getting Started

First step is you want to install autohotkey 



### Installation

1. Download Autohotkey at [this](https://www.autohotkey.com/)
2. Install Program

### Download Macro

• How to Download it? [this](https://youtu.be/Y02T8AiiJxw)

### Tutorial
   • Watch [this](https://youtu.be/5GATHIJGlSg) video <br>
    more info [Discord](https://discord.gg/4rxfjtnMGt)




<!-- <p align="right">(<a href="#top">back to top</a>)</p>


